# Constructing Disability Discourse on YouTube

This repository accompanies the revised manuscript, **Constructing Disability Discourse on YouTube: Sentiment, Stigma, Support, Parental Expertise, and Inclusive Education across Autism, ADHD, Cerebral Palsy, and Down Syndrome**.

## What is included

The repository contains the frozen deidentified feature matrix and code needed to reproduce the revised numerical analyses that are supported by that matrix. The primary four condition corpus is defined as videos classified exclusively as Autism, ADHD/ADD, Cerebral palsy, or Down syndrome. Other condition labels remain part of the source corpus for contextual and sensitivity analyses.

The repository also includes the available video selection audit, archived topic diagnostic values reported in the revised manuscript, and paraphrased topic examples. Raw YouTube comment text is not distributed.

## Repository structure

```text
.
├── README.md
├── REPRODUCIBILITY_BOUNDARY.md
├── requirements.txt
├── reproduce_results.py
├── src/
│   ├── __init__.py
│   ├── analysis.py
│   ├── figures.py
│   └── utils.py
├── data/
│   ├── derived/
│   │   ├── comment_level_features.csv.gz
│   │   └── README.md
│   └── documentation/
│       ├── topic_model_diagnostics.csv
│       ├── topic_representative_examples.csv
│       └── video_selection_audit.csv
├── validation/
│   └── README.md
├── outputs/
│   ├── figures/
│   └── tables/
└── tests/
    └── test_reproduction.py
```

## Reproduce the revised analyses

Python 3.10 or later is recommended.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python reproduce_results.py
```

On Windows PowerShell, activate the environment with:

```powershell
.venv\Scripts\Activate.ps1
```

The script writes manuscript tables and statistical outputs to `outputs/tables` and the two revised figures to `outputs/figures`.

## Verify expected results

```bash
pytest -q
```

The tests check core quantities reported in the revised paper, including 28,902 source comments, 23,355 focal comments, 17 focal videos, the video level H3 to H5 statistics, and principal mixed effects odds ratios.

## Important interpretation

The theme indicators and VADER sentiment scores are derived from the same comments. Their regression coefficients are therefore interpreted as descriptive co occurrence rather than causal effects or independent construct validation. The historical theme lexicons are not present in the archived public package, so exact theme term masking and VADER rescoring cannot be reconstructed without introducing a new, nonidentical lexicon.

The archived human validation worksheet does not contain completed coder and consensus labels. The revised manuscript consequently withdraws the previously reported adjudicated validation statistics. See `validation/README.md`.

## Data privacy

The released matrix excludes raw comment text and direct identifiers. Contributor identifiers are nonreversible keyed hashes used only for aggregate contributor dependence analysis.

## Reproducibility scope

See `REPRODUCIBILITY_BOUNDARY.md` for a precise statement of what can and cannot be reconstructed from the public archive.
