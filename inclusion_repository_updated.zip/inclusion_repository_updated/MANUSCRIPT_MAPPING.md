# Manuscript to repository mapping

This file maps the principal revised manuscript results to repository outputs.

| Revised manuscript component | Repository output |
| --- | --- |
| Source corpus and focal corpus counts | `outputs/tables/reproduction_summary.json` |
| Sampling framework by video stratum | `outputs/tables/Table_2_Corpus_Characteristics_by_Stratum.csv` |
| Data cleaning sequence | `outputs/tables/Table_3_Data_Cleaning.csv` |
| Video balanced sentiment across the four focal conditions | `outputs/tables/Table_4_Focal_Condition_Sentiment.csv` |
| Focal corpus discourse theme prevalence | `outputs/tables/Table_5_Focal_Theme_Prevalence.csv` |
| NMF nearest component prevalence | `outputs/tables/Table_6_Topic_Nearest_Component_Prevalence.csv` |
| Revised hypothesis evaluation | `outputs/tables/Table_7_Hypothesis_Evaluation.csv` |
| H3, H4, and H5 video level tests with Holm adjustment | `outputs/tables/Video_Level_Hypothesis_Tests.csv` |
| H4 negative proportion sensitivity | `outputs/tables/H4_Negative_Proportion_Sensitivity.csv` |
| Principal mixed effects logistic model | `outputs/tables/Mixed_Effects_Logistic_Principal.csv` |
| Mixed effects model excluding the two largest videos | `outputs/tables/Mixed_Effects_Logistic_Excluding_Two_Largest.csv` |
| Cluster robust exclusion sensitivity analysis | `outputs/tables/Supplementary_Table_S2_Cluster_Robust_Sensitivity.csv` |
| Topic maximum weight diagnostics | `outputs/tables/Topic_Weight_Diagnostics.csv` |
| Entity prevalence | `outputs/tables/Entity_Prevalence_Focal_Corpus.csv` |
| NMF candidate solution diagnostics retained in the archive | `data/documentation/topic_model_diagnostics.csv` |
| Video selection and known replacement audit | `data/documentation/video_selection_audit.csv` |
| Paraphrased representative examples for the 12 NMF topics | `data/documentation/topic_representative_examples.csv` |
| Figure 1 | `outputs/figures/Figure_1_Corpus_Distribution_by_Stratum.pdf` and `.png` |
| Figure 2 | `outputs/figures/Figure_2_Theme_Prevalence_Heatmap.pdf` and `.png` |

The documentation files are retained historical records and are not recomputed from the feature matrix. Their provenance and limits are described in `REPRODUCIBILITY_BOUNDARY.md`.
