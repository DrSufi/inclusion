from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.ticker import ScalarFormatter

from .utils import FOCAL_CONDITIONS, THEME_LABELS, focal_corpus


def make_corpus_figure(source: pd.DataFrame, out: Path) -> None:
    counts=source.groupby("stratum").size().sort_values()
    share=counts/counts.sum()*100
    fig,ax=plt.subplots(figsize=(9.2,4.8))
    bars=ax.barh(counts.index,counts.values)
    ax.set_xscale("log")
    ax.set_xlabel("Analytical comments, logarithmic scale")
    ax.grid(axis="x",linestyle=":",linewidth=0.7,alpha=0.6)
    ax.xaxis.set_major_formatter(ScalarFormatter())
    for bar,count,pct in zip(bars,counts,share):
        ax.text(bar.get_width()*1.06,bar.get_y()+bar.get_height()/2,f"{count:,} ({pct:.1f}%)",va="center")
    ax.margins(x=0.25)
    fig.savefig(out/"Figure_1_Corpus_Distribution_by_Stratum.png",dpi=300,bbox_inches="tight")
    fig.savefig(out/"Figure_1_Corpus_Distribution_by_Stratum.pdf",bbox_inches="tight")
    plt.close(fig)


def make_theme_heatmap(source: pd.DataFrame, out: Path) -> None:
    df=focal_corpus(source)
    rows=[]
    for condition in FOCAL_CONDITIONS:
        sub=df[df["primary_condition"]==condition]
        for col,label in THEME_LABELS.items():
            rows.append({"condition":condition,"theme":label,"prevalence":sub[col].mean()*100})
    matrix=pd.DataFrame(rows).pivot(index="theme",columns="condition",values="prevalence")
    matrix=matrix.reindex(index=list(THEME_LABELS.values()),columns=FOCAL_CONDITIONS).fillna(0)
    fig,ax=plt.subplots(figsize=(9.0,7.1))
    im=ax.imshow(matrix.to_numpy(),aspect="auto")
    ax.set_xticks(np.arange(len(FOCAL_CONDITIONS)))
    ax.set_xticklabels(["Autism","ADHD and ADD","Cerebral palsy","Down syndrome"],rotation=20,ha="right")
    ax.set_yticks(np.arange(len(matrix.index)))
    ax.set_yticklabels(matrix.index)
    threshold=matrix.to_numpy().max()/2
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            val=matrix.iat[i,j]
            ax.text(j,i,f"{val:.1f}",ha="center",va="center",color="white" if val>threshold else "black",fontsize=8)
    cbar=fig.colorbar(im,ax=ax,fraction=0.035,pad=0.03)
    cbar.set_label("Comments containing theme (%)")
    fig.savefig(out/"Figure_2_Theme_Prevalence_Heatmap.png",dpi=300,bbox_inches="tight")
    fig.savefig(out/"Figure_2_Theme_Prevalence_Heatmap.pdf",bbox_inches="tight")
    plt.close(fig)


def make_all_figures(source: pd.DataFrame, out: str | Path) -> None:
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    make_corpus_figure(source,out)
    make_theme_heatmap(source,out)
