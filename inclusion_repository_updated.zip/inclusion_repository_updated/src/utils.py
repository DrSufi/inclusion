from __future__ import annotations

from pathlib import Path
import numpy as np
import pandas as pd

FOCAL_CONDITIONS = ["Autism", "ADHD/ADD", "Cerebral palsy", "Down syndrome"]

THEME_LABELS = {
    "theme_Support_and_empathy": "Support and empathy",
    "theme_Parental_emotional_labour": "Parental emotional labour",
    "theme_Institutional_support_or_failure": "Institutional support or failure",
    "theme_Inclusive_education_and_accessibility": "Inclusive education and accessibility",
    "theme_Stigma_blame_and_judgement": "Stigma, blame, and judgement",
    "theme_Misinformation_and_contested_causation": "Misinformation and contested causation",
    "theme_Parental_expertise_and_advocacy": "Parental expertise and advocacy",
    "theme_Clinical_and_professional_guidance": "Clinical and professional guidance",
    "theme_Neurodiversity_identity_and_acceptance": "Neurodiversity, identity, and acceptance",
    "theme_Behaviour_and_safety_concerns": "Behaviour and safety concerns",
    "theme_Treatment_and_intervention_debate": "Treatment and intervention debate",
}

MIXED_MODEL_NAMES = {
    "theme_Support_and_empathy": "support",
    "theme_Parental_emotional_labour": "parental_labour",
    "theme_Institutional_support_or_failure": "institutional",
    "theme_Inclusive_education_and_accessibility": "inclusive",
    "theme_Stigma_blame_and_judgement": "stigma",
    "theme_Misinformation_and_contested_causation": "misinformation",
    "theme_Parental_expertise_and_advocacy": "parental_expertise",
    "theme_Clinical_and_professional_guidance": "clinical",
    "theme_Neurodiversity_identity_and_acceptance": "neurodiversity",
    "theme_Behaviour_and_safety_concerns": "behaviour_safety",
    "theme_Treatment_and_intervention_debate": "treatment",
}

TOPIC_LABELS = {
    1: "Family caregiving, support needs, and life course burden",
    2: "Diagnosis, severity, and contested causation",
    3: "Religious coping, prayer, and blessings",
    4: "Peer support networks for parents and caregivers",
    5: "Affection, solidarity, and emotional connection",
    6: "Disagreement, understanding, and disability identity",
    7: "ADHD diagnosis, self-identification, and behavioural regulation",
    8: "Cerebral palsy, development, and prognosis",
    9: "Autistic identity, masking, and communication",
    10: "Admiration of children and family resilience",
    11: "Parenting judgement, normality, and social expectations",
    12: "Special and inclusive education, teachers, and accessibility",
}

TOPIC_TERMS = {
    1: "child, parents, help, age, life",
    2: "autism, spectrum, disorder, diagnosis, severe",
    3: "God, blessing, family, prayer, hope",
    4: "children, special needs, mothers, support, community",
    5: "love, family, support, happiness, community",
    6: "understanding, disability, identity, need, support",
    7: "ADHD, diagnosis, relate, control, anger",
    8: "cerebral palsy, development, condition, movement, prognosis",
    9: "autistic identity, child, masking, communication, adult",
    10: "beautiful, family, resilience, hope, story",
    11: "children, normality, parenting, judgement, care",
    12: "education, school, teachers, inclusion, accessibility",
}

ENTITY_COLUMNS = {
    "entity_Autism": "Autism terminology",
    "entity_Parents_family": "Parent or family terminology",
    "entity_Learning_disability": "Learning disability terminology",
    "entity_Schools": "School terminology",
    "entity_Professionals": "Professional stakeholder terminology",
    "entity_ADHD_ADD": "ADHD and ADD terminology",
    "entity_Vaccines": "Vaccine terminology",
    "entity_Medication": "Medication terminology",
    "entity_Healthcare_services": "Healthcare service terminology",
}


def read_features(path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    bool_cols = [c for c in df.columns if c.startswith("theme_") or c.startswith("entity_")]
    for col in bool_cols:
        if df[col].dtype != bool:
            df[col] = df[col].astype(str).str.lower().map({"true": True, "false": False}).fillna(False)
    if df["reply"].dtype != bool:
        df["reply"] = df["reply"].astype(str).str.lower().map({"true": True, "false": False}).fillna(False)
    return df


def focal_corpus(df: pd.DataFrame) -> pd.DataFrame:
    return df[df["primary_condition"].isin(FOCAL_CONDITIONS)].copy()


def holm_adjust(p_values) -> np.ndarray:
    p = np.asarray(p_values, dtype=float)
    n = len(p)
    order = np.argsort(p)
    adjusted_sorted = np.empty(n, dtype=float)
    running = 0.0
    for rank, idx in enumerate(order):
        value = min(1.0, (n - rank) * p[idx])
        running = max(running, value)
        adjusted_sorted[rank] = running
    adjusted = np.empty(n, dtype=float)
    for rank, idx in enumerate(order):
        adjusted[idx] = adjusted_sorted[rank]
    return adjusted


def epsilon_squared_kw(H: float, n: int, k: int) -> float:
    if n <= k:
        return float("nan")
    return max(0.0, (H - k + 1) / (n - k))
