from __future__ import annotations

import numpy as np
import pandas as pd
import scipy.stats as st
import statsmodels.api as sm
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM

from .utils import (
    ENTITY_COLUMNS,
    FOCAL_CONDITIONS,
    MIXED_MODEL_NAMES,
    THEME_LABELS,
    TOPIC_LABELS,
    TOPIC_TERMS,
    epsilon_squared_kw,
    focal_corpus,
    holm_adjust,
)


def corpus_summary(source: pd.DataFrame) -> dict:
    focal = focal_corpus(source)
    author_counts = source["author_key"].value_counts()
    repeat_authors = int((author_counts > 1).sum())
    repeat_comments = int(author_counts[author_counts > 1].sum())
    top_two = source["video_id"].value_counts().head(2)
    return {
        "source_comments": int(len(source)),
        "source_videos": int(source["video_id"].nunique()),
        "source_contributors": int(source["author_key"].nunique()),
        "focal_comments": int(len(focal)),
        "focal_videos": int(focal["video_id"].nunique()),
        "focal_contributors": int(focal["author_key"].nunique()),
        "repeat_contributors": repeat_authors,
        "repeat_contributors_pct": repeat_authors / source["author_key"].nunique() * 100,
        "comments_from_repeat_contributors": repeat_comments,
        "comments_from_repeat_contributors_pct": repeat_comments / len(source) * 100,
        "two_largest_video_comments": int(top_two.sum()),
        "two_largest_video_pct": float(top_two.sum() / len(source) * 100),
        "two_largest_video_ids": top_two.index.tolist(),
    }


def stratum_table(source: pd.DataFrame) -> pd.DataFrame:
    per_video = source.groupby(["stratum", "video_id"]).size().rename("video_comments").reset_index()
    rows = []
    for stratum, group in source.groupby("stratum"):
        rows.append({
            "video_stratum": stratum,
            "videos": int(group["video_id"].nunique()),
            "comments": int(len(group)),
            "corpus_pct": len(group) / len(source) * 100,
            "distinct_authors": int(group["author_key"].nunique()),
            "median_comments_per_video": float(per_video.loc[per_video["stratum"] == stratum, "video_comments"].median()),
            "replies_pct": float(group["reply"].mean() * 100),
        })
    return pd.DataFrame(rows).sort_values("comments", ascending=False, ignore_index=True)


def cleaning_table() -> pd.DataFrame:
    return pd.DataFrame([
        {"processing_stage":"Raw parsed records", "records_retained":31164, "records_removed_at_stage":0, "percentage_retained":100.00},
        {"processing_stage":"Unique comment identifiers", "records_retained":31150, "records_removed_at_stage":14, "percentage_retained":99.96},
        {"processing_stage":"Nonempty normalised text", "records_retained":30775, "records_removed_at_stage":375, "percentage_retained":98.75},
        {"processing_stage":"English or language indeterminate comments", "records_retained":30772, "records_removed_at_stage":3, "percentage_retained":98.74},
        {"processing_stage":"Comments containing at least three words", "records_retained":28902, "records_removed_at_stage":1870, "percentage_retained":92.74},
    ])


def focal_sentiment_table(source: pd.DataFrame) -> pd.DataFrame:
    df = focal_corpus(source)
    per_video = df.groupby(["video_id", "primary_condition", "sentiment"]).size().unstack(fill_value=0)
    per_video = per_video.div(per_video.sum(axis=1), axis=0).reset_index()
    rows=[]
    for condition in FOCAL_CONDITIONS:
        selected = per_video[per_video["primary_condition"] == condition]
        raw = df[df["primary_condition"] == condition]
        rows.append({
            "disability_condition": condition.replace("ADHD/ADD", "ADHD and ADD"),
            "videos": int(selected["video_id"].nunique()),
            "analytical_comments": int(len(raw)),
            "positive_pct": float(selected.get("Positive", 0).mean() * 100),
            "neutral_pct": float(selected.get("Neutral", 0).mean() * 100),
            "negative_pct": float(selected.get("Negative", 0).mean() * 100),
        })
    return pd.DataFrame(rows)


def focal_overall_sentiment(source: pd.DataFrame) -> dict:
    df = focal_corpus(source)
    dist = df["sentiment"].value_counts(normalize=True) * 100
    return {k: float(dist.get(k, 0.0)) for k in ["Positive", "Neutral", "Negative"]}


def focal_theme_table(source: pd.DataFrame) -> pd.DataFrame:
    df = focal_corpus(source)
    rows=[]
    for col,label in THEME_LABELS.items():
        sub=df[df[col]]
        dist=sub["sentiment"].value_counts(normalize=True)
        rows.append({
            "discursive_theme":label,
            "comments":int(len(sub)),
            "prevalence_pct":float(len(sub)/len(df)*100),
            "positive_pct":float(dist.get("Positive",0)*100),
            "neutral_pct":float(dist.get("Neutral",0)*100),
            "negative_pct":float(dist.get("Negative",0)*100),
            "mean_sentiment":float(sub["sentiment_score"].mean()),
        })
    return pd.DataFrame(rows).sort_values("comments",ascending=False,ignore_index=True)


def topic_table(source: pd.DataFrame) -> pd.DataFrame:
    df=focal_corpus(source)
    grouped=df.groupby("topic_id").agg(comments=("row_id","size"),mean_sentiment=("sentiment_score","mean")).reset_index()
    grouped["prevalence_pct"]=grouped["comments"]/len(df)*100
    grouped["interpretive_label"]=grouped["topic_id"].map(TOPIC_LABELS)
    grouped["representative_terms"]=grouped["topic_id"].map(TOPIC_TERMS)
    return grouped[["topic_id","interpretive_label","representative_terms","comments","prevalence_pct","mean_sentiment"]].sort_values("topic_id")


def topic_weight_diagnostics(source: pd.DataFrame) -> pd.DataFrame:
    w=focal_corpus(source)["topic_weight"].dropna()
    return pd.DataFrame([{
        "n":int(len(w)),
        "median":float(w.median()),
        "q25":float(w.quantile(.25)),
        "q75":float(w.quantile(.75)),
        "p90":float(w.quantile(.90)),
        "p95":float(w.quantile(.95)),
    }])


def entity_prevalence(source: pd.DataFrame) -> pd.DataFrame:
    df=focal_corpus(source)
    rows=[]
    for col,label in ENTITY_COLUMNS.items():
        rows.append({"entity":label,"comments":int(df[col].sum()),"prevalence_pct":float(df[col].mean()*100)})
    return pd.DataFrame(rows).sort_values("prevalence_pct",ascending=False,ignore_index=True)


def video_level_tests(source: pd.DataFrame) -> pd.DataFrame:
    focal=focal_corpus(source)
    rows=[]

    h3=source.groupby(["video_id","stratum"])["theme_Inclusive_education_and_accessibility"].mean().reset_index()
    groups=[g["theme_Inclusive_education_and_accessibility"].to_numpy() for _,g in h3.groupby("stratum")]
    H3,p3=st.kruskal(*groups)
    rows.append({"hypothesis":"H3","comparison":"Video stratum and inclusive education/accessibility prevalence","statistic":float(H3),"df":4,"p_value":float(p3),"epsilon_squared":epsilon_squared_kw(H3,len(h3),5)})

    h4=focal.groupby(["video_id","primary_condition"])["sentiment_score"].mean().reset_index()
    groups=[g["sentiment_score"].to_numpy() for _,g in h4.groupby("primary_condition")]
    H4,p4=st.kruskal(*groups)
    rows.append({"hypothesis":"H4","comparison":"Focal condition and video-level mean sentiment","statistic":float(H4),"df":3,"p_value":float(p4),"epsilon_squared":epsilon_squared_kw(H4,len(h4),4)})

    h5=source.groupby(["video_id","stratum"])["sentiment_score"].mean().reset_index()
    groups=[g["sentiment_score"].to_numpy() for _,g in h5.groupby("stratum")]
    H5,p5=st.kruskal(*groups)
    rows.append({"hypothesis":"H5","comparison":"Video stratum and video-level mean sentiment","statistic":float(H5),"df":4,"p_value":float(p5),"epsilon_squared":epsilon_squared_kw(H5,len(h5),5)})

    out=pd.DataFrame(rows)
    out["p_holm"]=holm_adjust(out["p_value"].to_numpy())
    return out


def h4_negative_proportion_test(source: pd.DataFrame) -> pd.DataFrame:
    df=focal_corpus(source).copy()
    df["negative"]=(df["sentiment"]=="Negative").astype(int)
    per_video=df.groupby(["video_id","primary_condition"])["negative"].mean().reset_index()
    groups=[g["negative"].to_numpy() for _,g in per_video.groupby("primary_condition")]
    H,p=st.kruskal(*groups)
    return pd.DataFrame([{"statistic":float(H),"df":3,"p_value":float(p)}])


def fit_mixed_model(source: pd.DataFrame, exclude_two_largest: bool=False) -> pd.DataFrame:
    df=focal_corpus(source)
    if exclude_two_largest:
        top_two=source["video_id"].value_counts().head(2).index
        df=df[~df["video_id"].isin(top_two)].copy()
    else:
        df=df.copy()
    df=df.rename(columns=MIXED_MODEL_NAMES)
    df["negative"]=(df["sentiment"]=="Negative").astype(int)
    df["reply_i"]=df["reply"].astype(int)
    formula="negative ~ reply_i + " + " + ".join(MIXED_MODEL_NAMES.values()) + " + C(stratum)"
    np.random.seed(42)
    model=BinomialBayesMixedGLM.from_formula(formula,{"video":"0 + C(video_id)"},df)
    fitted=model.fit_vb()
    rows=[]
    for name,mean,sd in zip(model.exog_names,fitted.fe_mean,fitted.fe_sd):
        rows.append({
            "term":name,
            "log_odds_mean":float(mean),
            "posterior_sd":float(sd),
            "odds_ratio":float(np.exp(mean)),
            "interval_low":float(np.exp(mean-1.96*sd)),
            "interval_high":float(np.exp(mean+1.96*sd)),
        })
    return pd.DataFrame(rows)


def cluster_robust_model(df: pd.DataFrame) -> pd.DataFrame:
    theme_cols=list(THEME_LABELS)
    X=df[["reply"]+theme_cols].copy()
    X["reply"]=X["reply"].astype(int)
    for col in theme_cols:
        X[col]=X[col].astype(int)
    dummies=pd.get_dummies(df["stratum"],prefix="stratum",drop_first=True,dtype=int)
    X=pd.concat([X,dummies],axis=1)
    X=sm.add_constant(X,has_constant="add")
    y=(df["sentiment"]=="Negative").astype(int)
    fitted=sm.Logit(y,X).fit(disp=False,cov_type="cluster",cov_kwds={"groups":df["video_id"]})
    conf=fitted.conf_int()
    return pd.DataFrame({
        "term":fitted.params.index,
        "coefficient":fitted.params.values,
        "std_error":fitted.bse.values,
        "p_value":fitted.pvalues.values,
        "odds_ratio":np.exp(fitted.params.values),
        "ci_low":np.exp(conf[0].values),
        "ci_high":np.exp(conf[1].values),
    })


def sensitivity_table(source: pd.DataFrame) -> pd.DataFrame:
    scenarios={
        "Full source corpus":source,
        "Excluding schizophrenia and deafness":source[~source["primary_condition"].isin(["Schizophrenia","Deafness"])].copy(),
        "Excluding two largest videos":source[~source["video_id"].isin(source["video_id"].value_counts().head(2).index)].copy(),
    }
    selected=[
        "theme_Behaviour_and_safety_concerns",
        "theme_Parental_emotional_labour",
        "theme_Stigma_blame_and_judgement",
        "theme_Institutional_support_or_failure",
        "theme_Misinformation_and_contested_causation",
        "theme_Support_and_empathy",
    ]
    rows=[]
    fits={name:cluster_robust_model(df).set_index("term") for name,df in scenarios.items()}
    for term in selected:
        row={"theme":THEME_LABELS[term]}
        for name,fit in fits.items():
            row[name]=float(fit.loc[term,"odds_ratio"])
        rows.append(row)
    return pd.DataFrame(rows)


def hypothesis_table(source: pd.DataFrame) -> pd.DataFrame:
    mixed=fit_mixed_model(source).set_index("term")
    tests=video_level_tests(source).set_index("hypothesis")
    term_map={
        "H1a":"behaviour_safety[T.True]",
        "H1b":"parental_labour[T.True]",
        "H1c":"stigma[T.True]",
        "H1d":"institutional[T.True]",
        "H1e":"misinformation[T.True]",
        "H2":"support[T.True]",
    }
    relationship={
        "H1a":"Behaviour and safety concerns and negative sentiment",
        "H1b":"Parental emotional labour and negative sentiment",
        "H1c":"Stigma, blame, and judgement and negative sentiment",
        "H1d":"Institutional support or failure and negative sentiment",
        "H1e":"Misinformation and contested causation and negative sentiment",
        "H2":"Support and empathy and negative sentiment",
    }
    interp={
        "H1a":"Descriptive positive co-occurrence",
        "H1b":"Descriptive positive co-occurrence",
        "H1c":"Descriptive positive co-occurrence",
        "H1d":"Not robust in principal model",
        "H1e":"Not robust in principal model",
        "H2":"Descriptive inverse co-occurrence",
    }
    rows=[]
    for h,term in term_map.items():
        x=mixed.loc[term]
        rows.append({"hypothesis":h,"tested_relationship":relationship[h],"evidence":f"OR {x.odds_ratio:.2f}, 95% interval {x.interval_low:.2f} to {x.interval_high:.2f}","interpretation":interp[h]})
    rows.extend([
        {"hypothesis":"H3","tested_relationship":"Video framing and inclusive education discourse","evidence":f"H(4)={tests.loc['H3','statistic']:.2f}; p={tests.loc['H3','p_value']:.3f}; Holm p={tests.loc['H3','p_holm']:.3f}","interpretation":"Video-level contextual association observed"},
        {"hypothesis":"H4","tested_relationship":"Focal condition and video-level sentiment","evidence":f"H(3)={tests.loc['H4','statistic']:.2f}; p={tests.loc['H4','p_value']:.3f}; Holm p={tests.loc['H4','p_holm']:.3f}","interpretation":"Exploratory pattern only"},
        {"hypothesis":"H5","tested_relationship":"Video stratum and video-level sentiment","evidence":f"H(4)={tests.loc['H5','statistic']:.2f}; p={tests.loc['H5','p_value']:.3f}; Holm p={tests.loc['H5','p_holm']:.3f}","interpretation":"Not supported at video-level"},
    ])
    return pd.DataFrame(rows)
