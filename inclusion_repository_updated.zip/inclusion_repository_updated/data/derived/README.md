# Derived analytical data

`comment_level_features.csv.gz` is the frozen deidentified analytical feature matrix used by the revised manuscript.

It contains derived sentiment, theme, entity, topic, video context, reply status, and hashed contributor variables. It does not contain raw comment text, usernames, channel identifiers, comment identifiers, direct links to individual comments, exact timestamps, profile images, or votes.

The matrix supports independent inspection and reanalysis of the derived variables reported in the revised statistical analyses. It does not support reconstruction of the original text preprocessing, historical lexical dictionaries, entity gazetteers, or original NMF fitting pipeline.
