# Human validation status

The revised manuscript withdraws the previously reported 250 comment adjudicated validation statistics because the archived project materials do not contain completed human coder or consensus labels supporting those statistics.

A separate 300 comment worksheet exists in the private project archive with model generated labels, but its human coding fields are incomplete. It is therefore not presented as a completed validation dataset and is not used to claim VADER accuracy, intercoder reliability, or per theme classification performance.

No confusion matrix, class specific precision or recall, theme specific validation metric, or human adjudication statistic should be inferred from this repository.

If a future validation study is completed, it should be released as a versioned addition containing the sampling procedure, coding guide, coder labels, adjudicated consensus labels, and reproducible metric calculation code, subject to ethical and privacy review.
