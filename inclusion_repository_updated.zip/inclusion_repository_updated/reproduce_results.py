from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from src.analysis import (
    cleaning_table,
    corpus_summary,
    entity_prevalence,
    fit_mixed_model,
    focal_overall_sentiment,
    focal_sentiment_table,
    focal_theme_table,
    h4_negative_proportion_test,
    hypothesis_table,
    sensitivity_table,
    stratum_table,
    topic_table,
    topic_weight_diagnostics,
    video_level_tests,
)
from src.figures import make_all_figures
from src.utils import read_features


def main() -> None:
    parser=argparse.ArgumentParser(description="Reproduce the revised manuscript analyses from the frozen deidentified feature matrix.")
    parser.add_argument("--data",default="data/derived/comment_level_features.csv.gz")
    parser.add_argument("--tables",default="outputs/tables")
    parser.add_argument("--figures",default="outputs/figures")
    args=parser.parse_args()

    source=read_features(args.data)
    tables=Path(args.tables); tables.mkdir(parents=True,exist_ok=True)
    figures=Path(args.figures); figures.mkdir(parents=True,exist_ok=True)

    stratum_table(source).to_csv(tables/"Table_2_Corpus_Characteristics_by_Stratum.csv",index=False)
    cleaning_table().to_csv(tables/"Table_3_Data_Cleaning.csv",index=False)
    focal_sentiment_table(source).to_csv(tables/"Table_4_Focal_Condition_Sentiment.csv",index=False)
    focal_theme_table(source).to_csv(tables/"Table_5_Focal_Theme_Prevalence.csv",index=False)
    topic_table(source).to_csv(tables/"Table_6_Topic_Nearest_Component_Prevalence.csv",index=False)
    hypothesis_table(source).to_csv(tables/"Table_7_Hypothesis_Evaluation.csv",index=False)

    video_level_tests(source).to_csv(tables/"Video_Level_Hypothesis_Tests.csv",index=False)
    h4_negative_proportion_test(source).to_csv(tables/"H4_Negative_Proportion_Sensitivity.csv",index=False)
    fit_mixed_model(source).to_csv(tables/"Mixed_Effects_Logistic_Principal.csv",index=False)
    fit_mixed_model(source,exclude_two_largest=True).to_csv(tables/"Mixed_Effects_Logistic_Excluding_Two_Largest.csv",index=False)
    sensitivity_table(source).to_csv(tables/"Supplementary_Table_S2_Cluster_Robust_Sensitivity.csv",index=False)
    topic_weight_diagnostics(source).to_csv(tables/"Topic_Weight_Diagnostics.csv",index=False)
    entity_prevalence(source).to_csv(tables/"Entity_Prevalence_Focal_Corpus.csv",index=False)

    docs=Path("data/documentation")
    shutil.copy2(docs/"topic_model_diagnostics.csv", tables/"Table_1_NMF_Diagnostics.csv")
    shutil.copy2(docs/"video_selection_audit.csv", tables/"Supplementary_Table_S1_Video_Selection_Audit.csv")
    shutil.copy2(docs/"topic_representative_examples.csv", tables/"Supplementary_Table_S3_Topic_Examples.csv")

    summary=corpus_summary(source)
    summary["focal_sentiment_pct"]=focal_overall_sentiment(source)
    (tables/"reproduction_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    make_all_figures(source,figures)

    print(json.dumps(summary,indent=2))
    print(f"Tables written to {tables}")
    print(f"Figures written to {figures}")


if __name__ == "__main__":
    main()
