from pathlib import Path

import numpy as np

from src.analysis import corpus_summary, fit_mixed_model, video_level_tests
from src.utils import read_features

DATA=Path("data/derived/comment_level_features.csv.gz")


def test_core_counts():
    df=read_features(DATA)
    s=corpus_summary(df)
    assert s["source_comments"] == 28902
    assert s["source_videos"] == 29
    assert s["source_contributors"] == 20516
    assert s["focal_comments"] == 23355
    assert s["focal_videos"] == 17
    assert s["focal_contributors"] == 16238
    assert s["two_largest_video_comments"] == 18864
    assert np.isclose(s["two_largest_video_pct"],65.269,atol=0.02)


def test_video_level_hypotheses():
    df=read_features(DATA)
    t=video_level_tests(df).set_index("hypothesis")
    assert np.isclose(t.loc["H3","statistic"],15.24697,atol=1e-4)
    assert np.isclose(t.loc["H3","p_holm"],0.012646,atol=1e-4)
    assert np.isclose(t.loc["H4","statistic"],3.075817,atol=1e-4)
    assert np.isclose(t.loc["H4","p_holm"],0.760166,atol=1e-4)
    assert np.isclose(t.loc["H5","statistic"],3.057471,atol=1e-4)
    assert np.isclose(t.loc["H5","p_holm"],0.760166,atol=1e-4)


def test_principal_mixed_effects():
    df=read_features(DATA)
    m=fit_mixed_model(df).set_index("term")
    assert np.isclose(m.loc["behaviour_safety[T.True]","odds_ratio"],2.545,atol=0.02)
    assert np.isclose(m.loc["parental_labour[T.True]","odds_ratio"],2.443,atol=0.02)
    assert np.isclose(m.loc["stigma[T.True]","odds_ratio"],2.168,atol=0.02)
    assert np.isclose(m.loc["support[T.True]","odds_ratio"],0.339,atol=0.01)
