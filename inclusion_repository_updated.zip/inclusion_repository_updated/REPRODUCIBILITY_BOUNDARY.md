# Reproducibility boundary

This repository reproduces analyses that can be calculated from the frozen deidentified feature matrix.

Reproducible from the released matrix:

1. Source corpus and focal corpus counts.
2. Video stratum characteristics.
3. Four condition video balanced sentiment summaries.
4. Focal corpus theme prevalence and sentiment orientation.
5. Video level Kruskal Wallis tests for H3, H4, and H5 with Holm adjustment.
6. Mixed effects logistic regression with a video random intercept.
7. Cluster robust sensitivity models excluding schizophrenia and deafness and excluding the two largest videos.
8. Contributor repetition statistics.
9. Topic nearest component prevalence and maximum weight diagnostics.
10. Entity prevalence summaries.
11. Revised manuscript figures derived from the feature matrix.

Not reconstructable from the public archive:

1. Original YouTube search ranking beyond the documented selected and known replacement cases.
2. Raw comment collection and raw comment text.
3. Historical theme lexicons and entity gazetteers.
4. Original NMF fitting pipeline and complete candidate solution diagnostics.
5. Completed human validation labels or the previously reported adjudicated validation statistics.
6. Exact theme term masking and VADER rescoring using the historical lexicons.

The repository therefore supports reproduction of the revised derived variable analyses, not end to end reconstruction from raw YouTube text.
